import React, { useState, useEffect } from 'react';
import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const AdminPage = () => {
    const [pacientes, setPacientes] = useState([]);
    const [medicos, setMedicos] = useState([]);
    
    // Formularios
    const [pacienteData, setPacienteData] = useState({ nombres: '', apellidos: '', dni: '', telefono: '', correo: '' });
    const [citaData, setCitaData] = useState({ pacienteId: '', medicoId: '', fecha: '', motivo: '' });

    useEffect(() => {
        axios.get(`${API_BASE_URL}/pacientes`).then(res => setPacientes(res.data));
        axios.get(`${API_BASE_URL}/medicos`).then(res => setMedicos(res.data));
    }, []);

    const handleCreatePatient = (e) => {
        e.preventDefault();
        const user = JSON.parse(localStorage.getItem('user'));

        // ✅ CORRECCIÓN: Construimos el objeto completo que espera el DTO
        const registroCompleto = {
            paciente: pacienteData,
            antecedentes: [] // AÑADE ESTA LÍNEA para que el formato coincida
        };

        axios.post(`${API_BASE_URL}/pacientes`, registroCompleto, { // Enviamos el objeto completo
            headers: { 'X-Usuario-ID': user.idUsuario }
        })
        .then(res => {
            alert(`Paciente ${res.data.nombres} creado con éxito.`);
            axios.get(`${API_BASE_URL}/pacientes`).then(res => setPacientes(res.data)); // Refrescar lista
            setPacienteData({ nombres: '', apellidos: '', dni: '', telefono: '', correo: '' });
        })
        .catch(err => {
            console.error("Error al crear paciente:", err.response ? err.response.data : err);
            alert('Error al crear paciente. Revisa la consola para más detalles.');
        });
    };

    const handleAgendarCita = (e) => {
        e.preventDefault();
        const nuevaCita = {
            paciente: { idPaciente: citaData.pacienteId },
            medico: { idMedico: citaData.medicoId },
            fecha: citaData.fecha,
            motivo: citaData.motivo,
            hora: new Date().toLocaleTimeString('it-IT')
        };
        axios.post(`${API_BASE_URL}/citas`, nuevaCita)
            .then(() => {
                alert('Cita agendada con éxito.');
                setCitaData({ pacienteId: '', medicoId: '', fecha: '', motivo: '' });
            })
            .catch(() => alert('Error al agendar la cita.'));
    };

    return (
        <div>
            <div className="data-card">
                <h2>Panel de Recepcionista</h2>
                
                <form onSubmit={handleCreatePatient} className="cita-form">
                    <h3>Registrar Nuevo Paciente</h3>
                    <input name="nombres" value={pacienteData.nombres} onChange={(e) => setPacienteData({...pacienteData, nombres: e.target.value})} placeholder="Nombres" required />
                    <input name="apellidos" value={pacienteData.apellidos} onChange={(e) => setPacienteData({...pacienteData, apellidos: e.target.value})} placeholder="Apellidos" required />
                    <input name="dni" value={pacienteData.dni} onChange={(e) => setPacienteData({...pacienteData, dni: e.target.value})} placeholder="DNI" required />
                    <input name="telefono" value={pacienteData.telefono} onChange={(e) => setPacienteData({...pacienteData, telefono: e.target.value})} placeholder="Teléfono" />
                    <input name="correo" value={pacienteData.correo} onChange={(e) => setPacienteData({...pacienteData, correo: e.target.value})} placeholder="Correo" />
                    <button type="submit">Crear Paciente</button>
                </form>

                <hr style={{margin: '40px 0'}}/>

                <form onSubmit={handleAgendarCita} className="cita-form">
                    <h3>Agendar Cita</h3>
                    <select name="pacienteId" value={citaData.pacienteId} onChange={(e) => setCitaData({...citaData, pacienteId: e.target.value})} required>
                        <option value="">-- Selecciona Paciente --</option>
                        {pacientes.map(p => <option key={p.idPaciente} value={p.idPaciente}>{p.nombres} {p.apellidos}</option>)}
                    </select>
                    <select name="medicoId" value={citaData.medicoId} onChange={(e) => setCitaData({...citaData, medicoId: e.target.value})} required>
                        <option value="">-- Asignar Médico --</option>
                        {medicos.map(m => <option key={m.idMedico} value={m.idMedico}>Dr. {m.nombres} {m.apellidos}</option>)}
                    </select>
                    <input type="date" name="fecha" value={citaData.fecha} onChange={(e) => setCitaData({...citaData, fecha: e.target.value})} required />
                    <input type="text" name="motivo" value={citaData.motivo} onChange={(e) => setCitaData({...citaData, motivo: e.target.value})} placeholder="Motivo de la Cita" required/>
                    <button type="submit">Agendar Cita</button>
                </form>
            </div>
        </div>
    );
};
export default AdminPage;