import React from 'react';

const HomePage = () => {
  return (
    <div className="placeholder">
      <h2>Bienvenido al Sistema de Gestión Hospitalaria</h2>
      <p>Selecciona una opción del menú para comenzar.</p>
    </div>
  );
};

export default HomePage;